package com.tiktok.info;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
